const socket = io();
const loginContainer = document.getElementById("login-container");
const chatContainer = document.getElementById("chat-container");
const usernameInput = document.getElementById("username-input");
const enterBtn = document.getElementById("enter-btn");
const form = document.getElementById("form");
const input = document.getElementById("input");
const messages = document.getElementById("messages");
const notifySound = document.getElementById("notify-sound");

let myId = null;

enterBtn.addEventListener("click", () => {
  const username = usernameInput.value.trim();
  if (!username) return;
  socket.emit("set username", username);
  loginContainer.classList.add("hidden");
  chatContainer.classList.remove("hidden");
});

socket.on("welcome", (data) => {
  myId = socket.id;
});

form.addEventListener("submit", function(e) {
  e.preventDefault();
  if (input.value) {
    socket.emit("chat message", input.value);
    input.value = "";
  }
});

socket.on("chat message", function(data) {
  const item = document.createElement("li");
  item.classList.add("message");
  item.classList.add(data.id === socket.id ? "mine" : "other");

  const avatar = document.createElement("img");
  avatar.src = data.avatar;

  const container = document.createElement("div");
  container.classList.add("text");

  const username = document.createElement("div");
  username.classList.add("username");
  username.textContent = data.username;

  const text = document.createElement("div");
  text.textContent = data.msg;

  const timestamp = document.createElement("div");
  timestamp.classList.add("timestamp");
  timestamp.textContent = data.timestamp;

  container.appendChild(username);
  container.appendChild(text);
  container.appendChild(timestamp);

  if (data.id === socket.id) {
    item.appendChild(container);
    item.appendChild(avatar);
  } else {
    item.appendChild(avatar);
    item.appendChild(container);
    notifySound.play();
  }

  messages.appendChild(item);
  messages.scrollTop = messages.scrollHeight;
});